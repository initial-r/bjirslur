# n3rflix_autopay
Ntahlah iseng doang bg

Penggunaan:
```bash
git clone https://github.com/yaelahda/n3rflix_autopay
cd n3rflix_autopay
npm i
node index.js
```

Paste ccmu di file cc.txt dengan format
```bash
cc|mm|yyyy|cvv
```

Note: Edit Passwordmu di line 34

Tq sgb

